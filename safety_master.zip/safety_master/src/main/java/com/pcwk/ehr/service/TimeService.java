package com.pcwk.ehr.service;

public interface TimeService {

	public String getNewDateTime();

	public String getDateTime();

}
