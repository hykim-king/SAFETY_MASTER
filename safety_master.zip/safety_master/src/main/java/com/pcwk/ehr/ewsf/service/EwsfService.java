package com.pcwk.ehr.ewsf.service;

import com.pcwk.ehr.ewsf.domain.EwsfVO;

import java.util.List;

public interface EwsfService {
    List<EwsfVO> getEWSF();
}
